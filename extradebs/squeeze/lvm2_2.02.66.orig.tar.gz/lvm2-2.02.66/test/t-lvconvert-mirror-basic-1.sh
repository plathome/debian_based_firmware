. ./t-lvconvert-mirror-basic.sh
test_many 1
